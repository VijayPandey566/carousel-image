const carousel = document.getElementById("carousel");
const cards = carousel.querySelectorAll(".card");
const dotsContainer = document.getElementById("dots");

let activeIndex = 2;

function updateCarousel() {
  cards.forEach((card, index) => {
    card.classList.toggle("active", index === activeIndex);
  });
  const cardWidth = cards[0].offsetWidth + 20;
  const offset =
    -activeIndex * cardWidth +
    (carousel.parentElement.offsetWidth / 2 - cardWidth / 2);
  carousel.style.transform = `translateX(${offset}px)`;

  // Update dots
  dotsContainer.innerHTML = "";
  cards.forEach((_, i) => {
    const dot = document.createElement("div");
    dot.className = "dot" + (i === activeIndex ? " active" : "");
    dot.addEventListener("click", () => {
      activeIndex = i;
      updateCarousel();
    });
    dotsContainer.appendChild(dot);
  });
}


cards.forEach((card, index) => {
  card.addEventListener("click", () => {
    activeIndex = index;
    updateCarousel();
  });
});


updateCarousel();
